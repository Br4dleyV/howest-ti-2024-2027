﻿using HoldMyBeer.Domain.Entities;
using HoldMyBeer.Domain.Interfaces;
using HoldMyBeer.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace HoldMyBeer.Infrastructure.Repositories
{
    public class BeerRepository : IBeerRepository
    {
        private readonly BeersContext _db;

        public BeerRepository(BeersContext context)
        {
            _db = context;
        }

        public void Add(Beer beer)
        {
            _db.Beers.Add(beer);
            _db.SaveChanges();
        }

        public void Delete(int id)
        {
            _db.Beers
                .Where(b => b.BeerId == id)
                .ExecuteDelete();
        }

        public IEnumerable<Beer> GetAll()
        {
            return _db.Beers
                .OrderBy(b => b.BeerName)
                .AsNoTracking()
                .ToList();
        }

        public (IEnumerable<Beer> Items, int TotalItems) GetPaged(int pageNumber, int pageSize, string? filterByType, float? minAlcohol, float? maxAlcohol)
        {
            IQueryable<Beer> query = _db.Beers
                .Include(b => b.Type)
                .AsNoTracking();

            if (!string.IsNullOrWhiteSpace(filterByType))
            {
                query = query.Where(b => b.Type != null && b.Type.Type != null && b.Type.Type == filterByType);
            }

            if (minAlcohol.HasValue)
            {
                query = query.Where(b => b.Alcohol.HasValue && b.Alcohol.Value >= minAlcohol.Value);
            }

            if (maxAlcohol.HasValue)
            {
                query = query.Where(b => b.Alcohol.HasValue && b.Alcohol.Value <= maxAlcohol.Value);
            }

            int totalItems = query.Count();

            List<Beer> items = query
                .OrderBy(b => b.BeerName)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            return (items, totalItems);
        }

        public Beer? GetById(int id)
        {
            return _db.Beers
                .AsNoTracking()
                .FirstOrDefault(b => b.BeerId == id);
        }
    }
}
