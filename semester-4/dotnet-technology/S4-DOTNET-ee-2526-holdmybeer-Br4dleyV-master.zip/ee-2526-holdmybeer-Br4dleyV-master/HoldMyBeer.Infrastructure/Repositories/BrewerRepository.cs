﻿using HoldMyBeer.Domain.Entities;
using HoldMyBeer.Domain.Interfaces;
using HoldMyBeer.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace HoldMyBeer.Infrastructure.Repositories
{
    public class BrewerRepository : IBrewerRepository
    {
        private readonly BeersContext _db;

        public BrewerRepository(BeersContext context)
        {
            _db = context;
        }

        public IEnumerable<Brewer> GetAll(string? name)
        {
            if (string.IsNullOrWhiteSpace(name)) {
                return _db.Brewers
                    .Include(b => b.Beers)
                    .AsNoTracking()
                    .ToList();
            } else
            {
                return _db.Brewers
                    .Include(b => b.Beers)
                    .AsNoTracking()
                    .Where(b => b.BrewerName!.Contains(name))
                    .ToList();
            }
        }

        public Brewer? GetById(int id)
        {
            return _db.Brewers
                .Include(b => b.Beers)
                .AsNoTracking()
                .FirstOrDefault(b => b.BrewerId == id);
        }
    }
}
