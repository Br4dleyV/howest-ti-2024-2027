﻿using System;
using System.Collections.Generic;
using HoldMyBeer.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace HoldMyBeer.Infrastructure.Data;

public partial class BeersContext : DbContext
{
    public BeersContext()
    {
    }

    public BeersContext(DbContextOptions<BeersContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Beer> Beers { get; set; }

    public virtual DbSet<BeerTaster> BeerTasters { get; set; }

    public virtual DbSet<BeerType> BeerTypes { get; set; }

    public virtual DbSet<Brewer> Brewers { get; set; }

    public virtual DbSet<Person> Persons { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Beer>(entity =>
        {
            entity.HasKey(e => e.BeerId).HasName("pk_Beers");

            entity.HasOne(d => d.Brewer).WithMany(p => p.Beers).HasConstraintName("fk_Beers_brewerId");

            entity.HasOne(d => d.Type).WithMany(p => p.Beers).HasConstraintName("fk_Beers_typeId");
        });

        modelBuilder.Entity<BeerTaster>(entity =>
        {
            entity.HasKey(e => new { e.PersonId, e.BeerId }).HasName("pk_BeerTasters");

            entity.HasOne(d => d.Beer).WithMany(p => p.BeerTasters)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_BeerTasters_beerId");

            entity.HasOne(d => d.Person).WithMany(p => p.BeerTasters)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_BeerTasters_personId");
        });

        modelBuilder.Entity<BeerType>(entity =>
        {
            entity.HasKey(e => e.TypeId).HasName("pk_BeerTypes");
        });

        modelBuilder.Entity<Brewer>(entity =>
        {
            entity.HasKey(e => e.BrewerId).HasName("pk_Brewers");
        });

        modelBuilder.Entity<Person>(entity =>
        {
            entity.HasKey(e => e.PersonId).HasName("pk_Persons");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
