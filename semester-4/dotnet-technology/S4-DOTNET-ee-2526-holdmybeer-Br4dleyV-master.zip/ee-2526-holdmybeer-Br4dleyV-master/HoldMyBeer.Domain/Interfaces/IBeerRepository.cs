﻿using HoldMyBeer.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace HoldMyBeer.Domain.Interfaces
{
    public interface IBeerRepository
    {
        IEnumerable<Beer> GetAll();
        (IEnumerable<Beer> Items, int TotalItems) GetPaged(int pageNumber, int pageSize, string? filterByType, float? minAlcohol, float? maxAlcohol);
        Beer? GetById(int id);
        void Add(Beer beer);
        void Delete(int id);
    }
}
