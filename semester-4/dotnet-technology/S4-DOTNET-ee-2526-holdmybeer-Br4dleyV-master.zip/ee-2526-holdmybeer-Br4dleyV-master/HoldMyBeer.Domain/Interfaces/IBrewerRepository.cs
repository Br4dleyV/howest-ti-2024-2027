﻿using HoldMyBeer.Domain.Entities;

namespace HoldMyBeer.Domain.Interfaces
{
    public interface IBrewerRepository
    {
        IEnumerable<Brewer> GetAll(string? name);
        Brewer? GetById(int id);
    }
}
