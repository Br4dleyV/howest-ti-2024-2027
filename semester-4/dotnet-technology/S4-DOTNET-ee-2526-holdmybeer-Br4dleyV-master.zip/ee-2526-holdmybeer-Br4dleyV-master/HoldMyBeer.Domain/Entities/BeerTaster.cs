﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HoldMyBeer.Domain.Entities;

public partial class BeerTaster
{
    [Key]
    [Column("personId")]
    public int PersonId { get; set; }

    [Key]
    [Column("beerId")]
    public int BeerId { get; set; }

    [Column("comments")]
    [StringLength(1000)]
    public string? Comments { get; set; }

    [ForeignKey("BeerId")]
    [InverseProperty("BeerTasters")]
    public virtual Beer Beer { get; set; } = null!;

    [ForeignKey("PersonId")]
    [InverseProperty("BeerTasters")]
    public virtual Person Person { get; set; } = null!;
}
