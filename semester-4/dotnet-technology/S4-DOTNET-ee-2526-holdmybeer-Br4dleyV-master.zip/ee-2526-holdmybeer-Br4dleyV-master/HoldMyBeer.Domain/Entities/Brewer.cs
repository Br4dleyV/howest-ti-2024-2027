﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HoldMyBeer.Domain.Entities;

public partial class Brewer
{
    [Key]
    [Column("brewerId")]
    public int BrewerId { get; set; }

    [Column("brewerName")]
    [StringLength(50)]
    public string? BrewerName { get; set; }

    [Column("address")]
    [StringLength(50)]
    public string? Address { get; set; }

    [Column("postalCode")]
    public short? PostalCode { get; set; }

    [Column("city")]
    [StringLength(50)]
    public string? City { get; set; }

    [Column("revenue")]
    public int? Revenue { get; set; }

    [InverseProperty("Brewer")]
    public virtual ICollection<Beer> Beers { get; set; } = new List<Beer>();
}
