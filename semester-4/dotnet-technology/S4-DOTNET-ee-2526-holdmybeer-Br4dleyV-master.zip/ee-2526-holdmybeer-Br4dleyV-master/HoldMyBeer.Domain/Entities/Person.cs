﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HoldMyBeer.Domain.Entities;

public partial class Person
{
    [Key]
    [Column("personId")]
    public int PersonId { get; set; }

    [Column("firstname")]
    [StringLength(100)]
    public string? Firstname { get; set; }

    [Column("lastname")]
    [StringLength(100)]
    public string? Lastname { get; set; }

    [Column("gender")]
    [StringLength(1)]
    public string? Gender { get; set; }

    [Column("dateOfBirth")]
    public DateOnly? DateOfBirth { get; set; }

    [Column("dateDeceased")]
    public DateOnly? DateDeceased { get; set; }

    [InverseProperty("Person")]
    public virtual ICollection<BeerTaster> BeerTasters { get; set; } = new List<BeerTaster>();
}
