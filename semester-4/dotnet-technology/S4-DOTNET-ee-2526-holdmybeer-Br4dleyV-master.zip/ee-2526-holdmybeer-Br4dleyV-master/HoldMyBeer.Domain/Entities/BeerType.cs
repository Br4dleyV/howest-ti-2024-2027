﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HoldMyBeer.Domain.Entities;

public partial class BeerType
{
    [Key]
    [Column("typeId")]
    public int TypeId { get; set; }

    [Column("type")]
    [StringLength(50)]
    public string? Type { get; set; }

    [InverseProperty("Type")]
    public virtual ICollection<Beer> Beers { get; set; } = new List<Beer>();
}
