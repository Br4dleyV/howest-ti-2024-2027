﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HoldMyBeer.Domain.Entities;

public partial class Beer
{
    [Key]
    [Column("beerId")]
    public int BeerId { get; set; }

    [Column("beerName")]
    [StringLength(100)]
    public string? BeerName { get; set; }

    [Column("brewerId")]
    public int? BrewerId { get; set; }

    [Column("typeId")]
    public int? TypeId { get; set; }

    [Column("alcohol")]
    public float? Alcohol { get; set; }

    [InverseProperty("Beer")]
    public virtual ICollection<BeerTaster> BeerTasters { get; set; } = new List<BeerTaster>();

    [ForeignKey("BrewerId")]
    [InverseProperty("Beers")]
    public virtual Brewer? Brewer { get; set; }

    [ForeignKey("TypeId")]
    [InverseProperty("Beers")]
    public virtual BeerType? Type { get; set; }
}
