using HoldMyBeer.Domain.Entities;
using HoldMyBeer.Infrastructure.Data;
using HotChocolate.Data;
using Microsoft.EntityFrameworkCore;

namespace HoldMyBeer.GraphQL;

public class Query
{
    [UseFiltering]
    [UseSorting]
    public IQueryable<Beer> GetBeers([Service] BeersContext context)
        => context.Beers;

    public Task<Beer?> GetBeer(int id, [Service] BeersContext context)
        => context.Beers.FirstOrDefaultAsync(beer => beer.BeerId == id);

    [UseFiltering]
    [UseSorting]
    public IQueryable<Brewer> GetBrewers([Service] BeersContext context)
        => context.Brewers;
}
