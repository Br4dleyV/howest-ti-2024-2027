using HotChocolate;
using HotChocolate.Types;
using HoldMyBeer.Infrastructure.Data;
using BeerEntity = HoldMyBeer.Domain.Entities.Beer;
using BrewerEntity = HoldMyBeer.Domain.Entities.Brewer;

namespace HoldMyBeer.GraphQL.Types;

public class BrewerType : ObjectType<BrewerEntity>
{
    protected override void Configure(IObjectTypeDescriptor<BrewerEntity> descriptor)
    {
        descriptor.BindFieldsExplicitly();

        descriptor.Field(brewer => brewer.BrewerId);
        descriptor.Field(brewer => brewer.BrewerName);
        descriptor.Field(brewer => brewer.Address);
        descriptor.Field(brewer => brewer.PostalCode);
        descriptor.Field(brewer => brewer.City);
        descriptor.Field(brewer => brewer.Revenue);

        descriptor.Field("beers")
            .ResolveWith<Resolvers>(resolver => resolver.GetBeers(default!, default!));
    }

    private sealed class Resolvers
    {
        public IQueryable<BeerEntity> GetBeers([Parent] BrewerEntity brewer, [Service] BeersContext context)
            => context.Beers.Where(beer => beer.BrewerId == brewer.BrewerId);
    }
}
