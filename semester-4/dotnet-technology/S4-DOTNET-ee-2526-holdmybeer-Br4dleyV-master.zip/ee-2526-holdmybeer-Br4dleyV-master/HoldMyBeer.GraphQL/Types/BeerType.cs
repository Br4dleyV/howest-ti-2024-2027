using HoldMyBeer.Infrastructure.Data;
using HotChocolate;
using HotChocolate.Types;
using Microsoft.EntityFrameworkCore;
using BeerEntity = HoldMyBeer.Domain.Entities.Beer;
using BrewerEntity = HoldMyBeer.Domain.Entities.Brewer;

namespace HoldMyBeer.GraphQL.Types;

public class BeerType : ObjectType<BeerEntity>
{
    protected override void Configure(IObjectTypeDescriptor<BeerEntity> descriptor)
    {
        descriptor.BindFieldsExplicitly();

        descriptor.Field(beer => beer.BeerId);
        descriptor.Field(beer => beer.BeerName);
        descriptor.Field(beer => beer.BrewerId);
        descriptor.Field(beer => beer.TypeId);
        descriptor.Field(beer => beer.Alcohol);

        descriptor.Field("brewer")
            .ResolveWith<Resolvers>(resolver => resolver.GetBrewer(default!, default!));
    }

    private sealed class Resolvers
    {
        public Task<BrewerEntity?> GetBrewer([Parent] BeerEntity beer, [Service] BeersContext context)
        {
            if (!beer.BrewerId.HasValue)
            {
                return Task.FromResult<BrewerEntity?>(null);
            }

            return context.Brewers.FirstOrDefaultAsync(brewer => brewer.BrewerId == beer.BrewerId.Value);
        }
    }
}
