using HoldMyBeer.Infrastructure.Data;
using HoldMyBeer.GraphQL;
using HoldMyBeer.GraphQL.Types;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<BeersContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection") ?? 
        "Server=.\\SQLEXPRESS;Initial Catalog=BeersDatabase2026;Integrated Security=True;TrustServerCertificate=true"));

builder.Services
        .AddGraphQLServer()
        .AddQueryType<Query>()
        .AddType<BeerType>()
        .AddType<BrewerType>()
        .AddFiltering()
        .AddSorting();

var app = builder.Build();

app.MapGraphQL();

app.RunWithGraphQLCommands(args);
