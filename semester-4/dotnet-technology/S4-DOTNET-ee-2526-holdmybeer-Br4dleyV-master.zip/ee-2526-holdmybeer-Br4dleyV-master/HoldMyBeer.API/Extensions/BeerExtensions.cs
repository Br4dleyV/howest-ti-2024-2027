﻿using HoldMyBeer.API.Dtos;
using HoldMyBeer.Domain.Entities;
using System.Runtime.CompilerServices;

namespace HoldMyBeer.API.Extensions
{
    public static class BeerExtensions
    {
        public static IEnumerable<BeerDto> ToDto(this IEnumerable<Beer> beers)
        {
            return beers.Select(b => new BeerDto(b.BeerId, b.BeerName));
        }

        public static BeerDto ToDto(this Beer beer)
        {
            return new BeerDto(beer.BeerId, beer.BeerName);
        }
    }
}
