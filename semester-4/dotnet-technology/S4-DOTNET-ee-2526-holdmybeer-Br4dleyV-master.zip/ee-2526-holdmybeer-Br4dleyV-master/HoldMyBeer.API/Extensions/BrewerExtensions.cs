﻿using HoldMyBeer.API.Dtos;
using HoldMyBeer.Domain.Entities;
using System.Runtime.CompilerServices;

namespace HoldMyBeer.API.Extensions
{
    public static class BrewerExtensions
    {
        public static IEnumerable<BrewerDto> ToDto(this IEnumerable<Brewer> brewers)
        {
            return brewers.Select(b => new BrewerDto(b.BrewerId, b.BrewerName));
        }

        public static BrewerDto ToDto(this Brewer brewer)
        {
            return new BrewerDto(brewer.BrewerId, brewer.BrewerName);
        }
    }
}
