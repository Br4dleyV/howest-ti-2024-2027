﻿namespace HoldMyBeer.API.Dtos
{
    public record BeerDto(int BeerId, string BeerName);
}
