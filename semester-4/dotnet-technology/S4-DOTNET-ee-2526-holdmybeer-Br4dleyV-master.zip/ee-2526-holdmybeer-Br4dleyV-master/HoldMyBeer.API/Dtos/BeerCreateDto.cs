﻿using System.ComponentModel.DataAnnotations;

namespace HoldMyBeer.API.Dtos
{
    public record BeerCreateDto
    {
        [Required]
        [StringLength(100)]
        public string BeerName { get; init; }

        [Range(0.0, 100.0, ErrorMessage = "Alcohol percentage must be between 0 and 100%")]
        public float Alcohol { get; init; }
    }
}
