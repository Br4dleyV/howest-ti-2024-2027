﻿namespace HoldMyBeer.API.Dtos
{
    public record BrewerDto(int BrewerId, string BrewerName);
}
