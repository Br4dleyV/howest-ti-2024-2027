﻿using HoldMyBeer.API.Dtos;
using HoldMyBeer.Domain.Entities;
using HoldMyBeer.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using HoldMyBeer.API.Extensions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Caching.Distributed;
using System.Globalization;
using System.Text.Json;

namespace HoldMyBeer.API.Controllers.V1
{
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiVersion("1.0", Deprecated = true)]
    [Route("api/v1/[controller]")]
    [ApiController]
    public class BeersController : ControllerBase
    {
        private readonly IBeerRepository _beerRepository;
        private readonly IDistributedCache _cache;
        private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(5);

        public BeersController(IBeerRepository repository, IDistributedCache cache)
        {
            _beerRepository = repository;
            _cache = cache;
        }

        [HttpGet]
        [Authorize(Roles = "guest,admin")]
        public async Task<IActionResult> Get(
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? filterByType = null,
            [FromQuery] float? minAlcohol = null,
            [FromQuery] float? maxAlcohol = null)
        {
            pageNumber = Math.Max(1, pageNumber);
            pageSize = Math.Clamp(pageSize, 1, 50);

            string normalizedType = filterByType?.Trim().ToLowerInvariant() ?? "-";
            string min = minAlcohol?.ToString(CultureInfo.InvariantCulture) ?? "-";
            string max = maxAlcohol?.ToString(CultureInfo.InvariantCulture) ?? "-";
            string cacheKey = $"beers:v1:list:{pageNumber}:{pageSize}:{normalizedType}:{min}:{max}";
            string? cachedResult = await _cache.GetStringAsync(cacheKey);
            if (!string.IsNullOrWhiteSpace(cachedResult))
            {
                PagedResult<BeerDto>? cachedPagedResult = JsonSerializer.Deserialize<PagedResult<BeerDto>>(cachedResult);
                if (cachedPagedResult is not null)
                {
                    return Ok(cachedPagedResult);
                }
            }

            var result = _beerRepository.GetPaged(pageNumber, pageSize, filterByType, minAlcohol, maxAlcohol);
            IEnumerable<BeerDto> beerDtos = result.Items.ToDto();
            int totalPages = result.TotalItems == 0 ? 0 : (int)Math.Ceiling((double)result.TotalItems / pageSize);

            PagedResult<BeerDto> pagedResult = new()
            {
                Items = beerDtos,
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalItems = result.TotalItems,
                TotalPages = totalPages
            };

            await _cache.SetStringAsync(
                cacheKey,
                JsonSerializer.Serialize(pagedResult),
                new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = CacheTtl
                });

            return Ok(pagedResult);
        }

        [HttpGet]
        [Route("{id}")]
        [Authorize(Roles = "guest,admin")]
        public async Task<IActionResult> GetById(int id)
        {
            string cacheKey = $"beers:v1:id:{id}";
            string? cachedBeer = await _cache.GetStringAsync(cacheKey);
            if (!string.IsNullOrWhiteSpace(cachedBeer))
            {
                BeerDto? cachedBeerDto = JsonSerializer.Deserialize<BeerDto>(cachedBeer);
                if (cachedBeerDto is not null)
                {
                    return Ok(cachedBeerDto);
                }
            }

            Beer? beer = _beerRepository.GetById(id);

            if (beer == null)
                return NotFound();

            BeerDto beerDto = beer.ToDto();

            await _cache.SetStringAsync(
                cacheKey,
                JsonSerializer.Serialize(beerDto),
                new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = CacheTtl
                });

            return Ok(beerDto);
        }

        [HttpPost]
        [Authorize(Roles = "admin")]
        public IActionResult Create(BeerDto beerDto)
        {
            Beer beer = new Beer
            {
                BeerName = beerDto.BeerName,
                Alcohol = 0.0f
            };

            _beerRepository.Add(beer);

            return CreatedAtAction(nameof(GetById), new { id = beer.BeerId }, beer.ToDto());
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "admin")]
        public IActionResult Delete(int id)
        {
            Beer? existingBeer = _beerRepository.GetById(id);
            if (existingBeer == null)
                return NotFound();

            _beerRepository.Delete(id);
            return NoContent();
        }
        
}

    namespace HoldMyBeer.API.Controllers.V2
    {
        [ApiExplorerSettings(GroupName = "v2")]
        [ApiVersion("2.0")]
        [Route("api/v2/[controller]")]
        [ApiController]
        public class BeersController : ControllerBase
        {
            private readonly IBeerRepository _beerRepository;

            public BeersController(IBeerRepository repository)
            {
                _beerRepository = repository;
            }

            [HttpGet]
            [AllowAnonymous]
            public IActionResult Get()
            {
                IEnumerable<Beer> beers = _beerRepository.GetAll();

                IEnumerable<BeerDto> beerDtos = beers.ToDto();

                return Ok(beerDtos);
            }
        }
    }
}
