﻿using HoldMyBeer.API.Dtos;
using HoldMyBeer.Domain.Entities;
using HoldMyBeer.Domain.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HoldMyBeer.API.Extensions;
using Microsoft.AspNetCore.Authorization;

namespace HoldMyBeer.API.Controllers
{
    [Route("api/brewers")]
    [ApiController]
    public class BrewersController : ControllerBase
    {
        private readonly IBrewerRepository _brewerRepository;

        public BrewersController(IBrewerRepository repository)
        {
            _brewerRepository = repository;
        }

        [HttpGet]
        [Authorize(Roles = "guest,admin")]
        public IActionResult Get([FromQuery] string? name = null)
        {
            IEnumerable<Brewer> brewers = _brewerRepository.GetAll(name);

            IEnumerable<BrewerDto> brewerDtos = brewers.ToDto();

            return Ok(brewerDtos);
        }

        [HttpGet]
        [Route("{id}/beers")]
        [Authorize(Roles = "admin")]
        public IActionResult GetBeersByBrewerId(int id)
        {
            Brewer? brewer = _brewerRepository.GetById(id);

            if (brewer == null)
                return NotFound();

            IEnumerable<BeerDto> beerDtos = brewer.Beers.ToDto();

            return Ok(beerDtos);
        }
    }
}
