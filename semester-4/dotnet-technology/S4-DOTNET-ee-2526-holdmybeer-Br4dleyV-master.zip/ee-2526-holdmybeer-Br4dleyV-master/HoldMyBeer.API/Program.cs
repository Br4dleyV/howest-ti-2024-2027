using HoldMyBeer.Domain.Interfaces;
using HoldMyBeer.Infrastructure.Data;
using HoldMyBeer.Infrastructure.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi;
using System.Security.Claims;
using System.Text.Json;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<BeersContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection") ??
        throw new InvalidOperationException("Connection string not found")));
builder.Services.AddScoped<IBeerRepository, BeerRepository>();
builder.Services.AddScoped<IBrewerRepository, BrewerRepository>();

string redisConfiguration = builder.Configuration.GetConnectionString("Redis")
    ?? throw new InvalidOperationException("Redis connection string not found. Configure ConnectionStrings:Redis.");

builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = redisConfiguration;
});

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi("v1", options =>
{
    options.AddDocumentTransformer((document, _, _) =>
    {
        document.Info.Contact = new OpenApiContact
        {
            Name = "Bradley Velle",
            Email = "bradley.velle@student.howest.be"
        };

        return Task.CompletedTask;
    });
});
builder.Services.AddOpenApi("v2", options =>
{
    options.AddDocumentTransformer((document, _, _) =>
    {
        document.Info.Contact = new OpenApiContact
        {
            Name = "Bradley Velle",
            Email = "bradley.velle@student.howest.be"
        };

        return Task.CompletedTask;
    });
});

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = builder.Configuration["Keycloak:Authority"];
        options.Audience = builder.Configuration["Keycloak:Audience"];

        options.RequireHttpsMetadata = false;

        options.Events = new JwtBearerEvents
        {
            OnTokenValidated = context =>
            {
                if (context.Principal?.Identity is not ClaimsIdentity identity)
                {
                    return Task.CompletedTask;
                }

                void AddRoleClaims(IEnumerable<string> roles)
                {
                    foreach (string role in roles.Where(r => !string.IsNullOrWhiteSpace(r)))
                    {
                        if (!identity.HasClaim(ClaimTypes.Role, role))
                        {
                            identity.AddClaim(new Claim(ClaimTypes.Role, role));
                        }
                    }
                }

                var realmAccess = context.Principal.FindFirst("realm_access")?.Value;
                if (!string.IsNullOrWhiteSpace(realmAccess))
                {
                    using JsonDocument realmDoc = JsonDocument.Parse(realmAccess);
                    if (realmDoc.RootElement.TryGetProperty("roles", out JsonElement realmRoles))
                    {
                        AddRoleClaims(realmRoles.EnumerateArray().Select(r => r.GetString() ?? string.Empty));
                    }
                }

                var resourceAccess = context.Principal.FindFirst("resource_access")?.Value;
                if (!string.IsNullOrWhiteSpace(resourceAccess))
                {
                    using JsonDocument resourceDoc = JsonDocument.Parse(resourceAccess);
                    foreach (JsonProperty resource in resourceDoc.RootElement.EnumerateObject())
                    {
                        if (resource.Value.TryGetProperty("roles", out JsonElement resourceRoles))
                        {
                            AddRoleClaims(resourceRoles.EnumerateArray().Select(r => r.GetString() ?? string.Empty));
                        }
                    }
                }

                return Task.CompletedTask;
            }
        };
    });
builder.Services.AddAuthorization();

builder.Services.AddApiVersioning(o =>
{
    o.ReportApiVersions = true;
    o.AssumeDefaultVersionWhenUnspecified = true;
    o.DefaultApiVersion = new ApiVersion(1, 0);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();

    app.MapScalarApiReference(option =>
    {
        option.Title = "HoldMyBeer API";

        option
            .AddDocument("v1", "API Version 1.0", "/openapi/v1.json", isDefault: true)
            .AddDocument("v2", "API Version 2.0", "/openapi/v2.json");
    });
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
